	 
<style>
.back-trans
    background-color: transparent;
}	 

</style>
	  <div class="modal fade" id="loadedAlertModal">
		<div class="modal-dialog">
		  <div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
			<!-- Modal body -->
			<div class="modal-body text-center back-trans">
			  <h5 class="" style="color:green" id="loader-title">File(s) uploaded Successfully.</h5>
				<div  class="d-flex justify-content-center back-trans" >
					<button id="" type="button" class="btn btn-info m-auto"  data-dismiss="modal" aria-label="Close" >Continue...</button>
					<!--
					<div id="div-loader" class="spinner-grow text-warning" role="status">
					  <span class="sr-only">Loading...</span>
					</div>
					-->
				</div>
			  
			  
			</div>
			
			
		  </div>
		</div>
	  </div>
  
