	 
<style>
.back-trans
    background-color: transparent;
}	 

</style>
	  <div class="modal fade" id="loaderModal">
		<div class="modal-dialog">
		  <div class="modal-content">
			
			<!-- Modal body -->
			<div class="modal-body text-center back-trans">
			  <h5 class="" style="color:#3230c3" id="loader-title">Please Wait...Uploading Media...</h5>
				<div  class="d-flex justify-content-center back-trans" >
					<div id="div-loader" class="spinner-grow text-warning" role="status">
					  <span class="sr-only">Loading...</span>
					</div>
				</div>
			  
			  
			</div>
			
			
		  </div>
		</div>
	  </div>
  
