<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Ela</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Ela">
	<meta name="_token" content="{{ csrf_token() }}">
	<link rel="icon" href="{{asset('public/ela-assets/images/logo.png')}}" type="image/gif" sizes="16x16">
	@include('layouts.ela-library')
</head>
