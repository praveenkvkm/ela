
    <script src="{{asset('public/ela-assets/js/main.js')}}"></script>
    <script src="{{asset('public/ela-assets/js/scripts.js')}}"></script>

